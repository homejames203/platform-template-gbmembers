{
  'info' =>
  {
    'username' => 'admin',
    'password' => '',
    'kinetic_task_location' => 'http://test.kineticdata.com/kinetic-task',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' =>
  {
    'error_handling' => 'Error Message',
    'source' => 'Playground',
    'group' => 'test',
    'name' => 'Complete'
    }
}