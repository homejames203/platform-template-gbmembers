{
  'info' => {
    'api_server' => '',
    'api_username' => '',
    'api_password' => '',
    'enable_debug_logging' => 'true'
  },
    'parameters' => {
      'api_server' => '',
      'error_handling' => 'Error Message',
      'issue_guid' => '',
      'email' => ''
    }
}
