{
  'info' => {
    'access_key' => '',
    'secret_key' => '',
    'region' => 'us-east-1',
    'request_ce_server' => '',
    'request_ce_username' => '',
    'request_ce_password' => '',
    'space_slug' => 'internal',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'region' => '',
    'space_slug' => '',
    'bucket' => 'task-handlers',
    'file_name' => 'gitlab/gitlab.png',
    'submission_id' => 'deef9759-a860-11e7-80a9-d73e96e1721e',
    'field' => 'Icon'
  }
}