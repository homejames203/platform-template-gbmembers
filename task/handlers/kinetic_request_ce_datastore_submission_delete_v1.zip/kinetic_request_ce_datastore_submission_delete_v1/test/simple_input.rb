{
  'info' => {
    'api_server' => 'https://localhost:8080/kinetic',
    'api_username' => 'user@kineticdata.com',
    'api_password' => 'password',
    'space_slug' => 'acme',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'space_slug' => '',
    'submission_id' => '36aedef7-007a-11e8-bbfe-efb8753e7164'
  }
}
