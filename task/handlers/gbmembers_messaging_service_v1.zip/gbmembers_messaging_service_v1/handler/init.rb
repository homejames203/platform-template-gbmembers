# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

class GbmembersMessagingServiceV1
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    # Load the debug logging and error handling info/parameter values into local variables
    @debug_logging_enabled = @info_values['enable_debug_logging'].downcase == 'yes' || @info_values['enable_debug_logging'] == 'true'
  end

  def execute
    # Initialize return data
    error_message = ""

    # To have the RestClient log to stdout (either the terminal if running the test harness or the
    # log file if running inside of task), set RestClient.log = "stdout" before making your Request
    # RestClient.log = "stdout"

    ################################################################################
    #               DOING A GET REQUEST TO RETRIEVE INFORMATION                    #
    ################################################################################

    headers = {
      :content_type => "application/json",
      :accept => "application/json"
    }
    puts "Calling the Messaging Service URL:#{@parameters['service_url']}/#{@parameters['service_value']}" if @debug_logging_enabled
    resource = RestClient::Resource.new("#{@parameters['service_url']}/#{@parameters['service_value']}",{:headers => headers})

    puts "Calling the Messaging Service ARGS:#{@parameters['json_args']}" if @debug_logging_enabled
    begin
      response = resource.post("#{@parameters['json_args']}")
    rescue RestClient::Exception => e
        raise
    end

    # Return (and escape) the results that were defined in the node.xml
    results = <<-RESULTS
    <results>
      <result name="Result JSON">#{escape(response)}</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS

    return results
  end

  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
end
