{
  'info' => {
    'api_server' => 'http://test.kineticdata.com/kinetic',
    'api_username' => 'test@kineticdata.com',
    'api_password' => '',
    'space_slug' => 'n1k',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'space_slug' => '',
    'submission_id' => 'e1614534-84c9-11e6-800e-519f50867cf3'
  }
}
