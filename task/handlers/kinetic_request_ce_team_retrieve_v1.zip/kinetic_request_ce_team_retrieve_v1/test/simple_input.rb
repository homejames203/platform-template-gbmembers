{
  'info' => {
    'api_server' => '',
    'api_username' => '',
    'api_password' => '',
    'space_slug' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'team_name' => 'IT',
    'space_slug' => '',
    'membership' => 'true',
    'attributes' => 'true'
  }
}
