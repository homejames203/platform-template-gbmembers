# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

class GenerateJourneyEventsV1
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    @api_server       =   @info_values['api_server']
    @api_username     =   URI.encode(@info_values['api_username'])
    @api_password     =   @info_values['api_password']

    # Load the debug logging and error handling info/parameter values into local variables
    @debug_logging_enabled = @info_values['enable_debug_logging'].downcase == 'yes' || @info_values['enable_debug_logging'] == 'true'
  end

  def execute
    # Initialize return data
    error_message = ""

    # To have the RestClient log to stdout (either the terminal if running the test harness or the
    # log file if running inside of task), set RestClient.log = "stdout" before making your Request
    # RestClient.log = "stdout"

    ################################################################################
    #               DOING A GET REQUEST TO RETRIEVE INFORMATION                    #
    ################################################################################

    leadJourneyResult = JSON.parse(@parameters["journey_triggers_json"])
    leadJourneys = leadJourneyResult.length
    puts "leadJourneys:#{leadJourneys}"

    events=[]
    for i in 0..leadJourneyResult.length-1
      trigger = leadJourneyResult[i]
      events=events.concat(createJourneyEvents(trigger, @parameters["record_id"], @parameters["record_name"]))
    end


    # Return (and escape) the results that were defined in the node.xml
    results = <<-RESULTS
    <results>
      <result name="Result Event IDs">{
        "journeyEvents": #{events},
        }</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS

    return results
  end

  def createJourneyEvents(trigger, recordID, recordName)
    events=[]
    journey_event_api_route = "#{@api_server}/app/api/v1/datastore/forms/journey-event/submissions"
    journey_event_resource = RestClient::Resource.new(journey_event_api_route, { :user => @api_username, :password => @api_password })

    data = {}
    values={}
    values['Status']="New"
    values['Trigger ID']=trigger["id"]
    values['Record Type']=trigger["values"]["Record Type"]
    values['Record ID']=recordID
    values['Record Name']=recordName
    values['Action']=trigger["values"]["Action"]
    values['Contact Type']=trigger["values"]["Contact Type"]
    values['Template Name']=trigger["values"]["Template Name"]

    data.tap do |json|
      json[:values] = values
    end
    response=nil
    begin
      response = journey_event_resource.post(data.to_json, { :accept => "json", :content_type => "json" })
    rescue RestClient::Exception => error
      puts "#{error.http_code}: #{JSON.parse(error.response)["error"]}"
    rescue Exception => error
      puts "#{error.inspect}"
    end
    if !response.nil?
      submission = JSON.parse(response)
      submission_id = submission['submission']['id']
      puts "SUBMISSION: #{submission_id}"
      events.push(submission_id)
    end
    return events
  end
  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
end
