{
  'info' => {
    'api_server' => 'https:/yourserver.com/kinetic',
    'api_username' => '',
    'api_password' => '',
    'space_slug' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'space_slug' => '',
    'kapp_slug' => 'services',
    'form_slug' => '',
    'submission_id' => '0777ba53-4751-11e8-a835-274eb2f3015e',
    'username' => '',
    'addt_vars' => '{"testAddtlVar-NAME":"testAddtlVar-VALUE"}',
    'backups' => '{"spaceAttributes":{"testAttribute":"testAttributeValue"}}',
  }
}
