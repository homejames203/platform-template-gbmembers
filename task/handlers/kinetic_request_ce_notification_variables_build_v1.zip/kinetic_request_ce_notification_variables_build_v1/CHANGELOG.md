Kinetic Request CE Notification Variables Build V1 (2017-02-18)
 * Initial version.  See README for details.

Kinetic Request CE Notification Variables Build V1.1 (2018-04-24)
* URI encoded username parameter so that this handler will work with all usernames

Kinetic Request CE Notification Variables Build V1.2 (2018-06-05)
* API Server Info Value changed to allow ${space} in the url for subdomain support
(ie. https://${space}.localhost:8080/kinetic)