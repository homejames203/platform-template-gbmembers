{
  'info' => {
    'api_server' => '',
    'api_username' => '',
    'api_password' => '',
    'space_slug' => '',
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
	'space_slug' => '',
    'current_name' => '',
    'description' => '',
    'new_name' => '',
    'append_or_replace' => 'Append',
    'attributes' =>  '[{"name": "Manager","values": ["Testing"]}]'
  }
}
