{
  'info' => {
    'api_server' => 'https://test.company.com',
    'api_username' => '',
    'api_password' => '',
    'space_slug' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'space_slug' => '',
    'submission_id' => '4ad3c59a-a863-11e6-a401-69db543717c9',
    'return_type' => 'XML'
  }
}
