{
  'info' => {
    'api_server' => 'https://yourserver/kinetic',
    'api_username' => '',
    'api_password' => '',
    'space_slug' => ''
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'space_slug' => ''
  }
}
