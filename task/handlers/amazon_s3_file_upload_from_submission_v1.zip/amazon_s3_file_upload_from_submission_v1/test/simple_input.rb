{
  'info' => {
    'access_key' => 'AKIAWGK46TGOAHXEBB65',
    'secret_key' => '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',
    'region' => 'ap-southeast-2',
    'request_ce_server' => 'gbmembers-template.kinops.io',
    'request_ce_username' => 'unus.gaffoor@kineticdata.com',
    'request_ce_password' => 'gbfms@2018',
    'space_slug' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'region' => 'ap-southeast-2',
    'space_slug' => '',
    'bucket' => 'gbmembers-photos',
    'file_name' => 'd32f9086-b5b1-11ea-b40e-dde76e4438d2-Unus%20Photo.jpg',
    'submission_id' => '944ab15f-c945-11e9-919c-ad321a71c5bc',
    'field' => 'Photo'
  }
}
