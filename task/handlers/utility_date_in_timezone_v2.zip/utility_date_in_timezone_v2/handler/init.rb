# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))


class UtilityDateInTimezoneV2
  def initialize(input)

    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    @enable_debug_logging = @info_values['enable_debug_logging'].downcase == 'yes' ||
                            @info_values['enable_debug_logging'].downcase == 'true'
    puts "Parameters: #{@parameters.inspect}" if @enable_debug_logging
  end

  def execute
    #TZInfo::DataSource.set(:ruby)

    # Set tz to be the timezone set by the input parameter
    tz = TZInfo::Timezone.get(@parameters["timezone"])

    #current_time = Time.now.utc
    current_time = DateTime.now
    #current_time = Time.parse(@parameters['timestamp']).utc if !@parameters['timestamp'].to_s.empty?
    current_time = DateTime.parse(@parameters['timestamp']) if !@parameters['timestamp'].to_s.empty?
    puts "Using Time (in UTC): #{current_time}" if @enable_debug_logging

    # Convert the current time into the local time (timezone data doesn't matter)
    if @parameters['direction'] == "To Local"
      #now = tz.utc_to_local(current_time)
      now = tz.to_local(current_time)
    else
      now = tz.local_to_utc(current_time)
    end
    puts "Direction #{@parameters['direction']} Time: #{now}" if @enable_debug_logging

    # Extract the date portion of the current time, ignoring timzone.
    # This gives us the current *date* in the local timezone in format YYYY-MM-DD.
    # Which can be compared to a date field
    date_conversion = now.to_date.to_s

  # Build the results to be returned by this handler
    return <<-RESULTS
    <results>
      <result name="Timezone">#{escape(@parameters["timezone"])}</result>
      <result name="Direction">#{@parameters["direction"]}</result>
      <result name="Date">#{escape(date_conversion)}</result>
      <result name="Time (ignore offset)">#{escape(now.iso8601)}</result>
      <result name="Offset Seconds">#{(current_time.to_time - tz.local_to_utc(current_time,true).to_time).round}</result>
    </results>
    RESULTS
  end

  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
end
