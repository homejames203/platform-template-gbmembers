Kinetic Request CE Submission Search V1.1 (2018-05-25)
* API Server Info Value changed to allow ${space} in the url for subdomain support
(ie. https://${space}.localhost:8080/kinetic)

Kinetic Request CE Submission Search V1 (2017-11-08)
* Initial version.  See README for details.
