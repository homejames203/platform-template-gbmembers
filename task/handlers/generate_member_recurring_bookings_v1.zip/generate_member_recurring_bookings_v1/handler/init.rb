# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

class GenerateMemberRecurringBookingsV1
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    @api_server       =   @info_values['api_server']
    @api_username     =   URI.encode(@info_values['api_username'])
    @api_password     =   @info_values['api_password']

    # Load the debug logging and error handling info/parameter values into local variables
    @debug_logging_enabled = @info_values['enable_debug_logging'].downcase == 'yes' || @info_values['enable_debug_logging'] == 'true'
  end

  def execute
    # Initialize return data
    error_message = ""

    ################################################################################
    #               DOING A GET REQUEST TO RETRIEVE INFORMATION                    #
    ################################################################################
    space_route = "#{@api_server}/app/api/v1/space?include=details"
    space_resource = RestClient::Resource.new(space_route, { :user => @api_username, :password => @api_password })
    space_response = space_resource.get
    spaceResult = JSON.parse(space_response)
    tzName=spaceResult["space"]["defaultTimezone"]
    tz=TZInfo::Timezone.get(tzName)
    puts "tzName:#{tzName}"

    # To have the RestClient log to stdout (either the terminal if running the test harness or the
    # log file if running inside of task), set RestClient.log = "stdout" before making your Request
    # RestClient.log = "stdout"

    ################################################################################
    #               DOING A GET REQUEST TO RETRIEVE INFORMATION                    #
    ################################################################################
    today_t = tz.utc_to_local(Time.now.utc)
    puts "today_t:#{today_t.strftime("%Y-%m-%d")}"
    bookings_query = %|values[Class Date]>="#{today_t.strftime("%Y-%m-%d")}"|
    bookings_api_route = "#{@api_server}/app/api/v1/datastore/forms/class-booking/submissions" +
              "?include=values&index=values[Class Date]&limit=1000&q=#{URI.escape(bookings_query)}"
    puts "bookings_api_route: #{bookings_api_route}"
    bookings_resource = RestClient::Resource.new(bookings_api_route, { :user => @api_username, :password => @api_password })
    bookings_response = bookings_resource.get
    bookingsResult = JSON.parse(bookings_response)
    bookings = bookingsResult["submissions"]
    puts "bookings:#{bookings.length}"


    recurring_bookings_query = %|values[Status]="Active"|
    recurring_bookings_api_route = "#{@api_server}/app/api/v1/datastore/forms/class-recurring-booking/submissions" +
              "?include=values&index=values[Status]&limit=1000&q=#{URI.escape(recurring_bookings_query)}"
    puts "recurring_bookings_api_route: #{recurring_bookings_api_route}"
    recurring_bookings_resource = RestClient::Resource.new(recurring_bookings_api_route, { :user => @api_username, :password => @api_password })
    recurring_bookings_response = recurring_bookings_resource.get
    recurringBookingsResult = JSON.parse(recurring_bookings_response)
    recurringBookings = recurringBookingsResult["submissions"]
    puts "recurringBookings:#{recurringBookings.length}"

    newBookings=[]
    for i in 0..recurringBookingsResult["submissions"].length-1
      newBooking = recurringBookingsResult["submissions"][i]
      if notBooked(newBooking, bookings, today_t)
        newBookings=newBookings.concat(createClassBooking(newBooking, today_t))
      end
    end


    # Return (and escape) the results that were defined in the node.xml
    results = <<-RESULTS
    <results>
      <result name="Result Booking IDs">{
        "newBookings": #{newBookings},
        }</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS

    return results
  end

  def notBooked(newBooking, bookings, today_t)
    classDate=getClassDate(newBooking["values"]["Class Day"].to_i, newBooking["values"]["Class Time"], today_t)
    puts "newBooking Date:#{classDate}"
    nowTime=today_t.strftime("%H:%M")

    puts "nowTime:#{nowTime}"
    for i in 0..bookings.length-1
      puts "newBooking: #{newBooking["values"]["Program"]}-#{newBooking["values"]["Title"]}-#{newBooking["values"]["Class Time"]}-#{newBooking["values"]["Member GUID"]}"
      puts "bookings[i]: #{bookings[i]["values"]["Program"]}-#{bookings[i]["values"]["Title"]}-#{bookings[i]["values"]["Class Time"]}-#{bookings[i]["values"]["Member GUID"]}"
      if (newBooking["values"]["Program"] == bookings[i]["values"]["Program"] && newBooking["values"]["Title"] == bookings[i]["values"]["Title"] && newBooking["values"]["Class Time"] == bookings[i]["values"]["Class Time"] && newBooking["values"]["Member GUID"] == bookings[i]["values"]["Member GUID"] && classDate==bookings[i]["values"]["Class Date"] && bookings[i]["values"]["Class Time"] == newBooking["values"]["Class Time"])
         return false
      end
    end
    return true
  end

  def getClassDate(day, classTime, today_t)
    today=today_t.to_date
    day=0 if day==7
    if (day==today.wday && today.strftime("%H:%M")<classTime)
      today=today
    elsif (day<=today.wday)
      today=today+((day-today.wday)+7)
    else
      today=today+(day-today.wday)
    end
    return today.strftime("%Y-%m-%d")
  end

  def createClassBooking(booking, today_t)
    events=[]
    class_booking_api_route = "#{@api_server}/app/api/v1/datastore/forms/class-booking/submissions?completed=true"
    class_booking_resource = RestClient::Resource.new(class_booking_api_route, { :user => @api_username, :password => @api_password })

    data = {}
    values={}
    values['Status']="Booked"
    values['Program']=booking["values"]["Program"]
    values['Title']=booking["values"]["Title"]
    values['Member ID']=booking["values"]["Member ID"]
    values['Member GUID']=booking["values"]["Member GUID"]
    values['Member Name']=booking["values"]["Member Name"]
    values['Class Date']=getClassDate(booking["values"]["Class Day"].to_i, booking["values"]["Class Time"], today_t)
    values['Class Time']=booking["values"]["Class Time"]

    data.tap do |json|
      json[:values] = values
    end
    response=nil
    begin
      response = class_booking_resource.post(data.to_json, { :accept => "json", :content_type => "json" })
    rescue RestClient::Exception => error
      puts "#{error.http_code}: #{JSON.parse(error.response)["error"]}"
    rescue Exception => error
      puts "#{error.inspect}"
    end
    if !response.nil?
      submission = JSON.parse(response)
      submission_id = submission['submission']['id']
      puts "SUBMISSION: #{submission_id}"
      events.push(submission_id)
    end
    return events
  end
  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
end
