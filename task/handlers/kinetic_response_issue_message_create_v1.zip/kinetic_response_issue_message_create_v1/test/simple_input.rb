{
  'info' => {
    'api_server' => '',
    'api_username' => '',
    'api_password' => '',
    'enable_debug_logging' => 'true'
  },
    'parameters' => {
      'error_handling' => 'Error Message',
      'api_server' => '',
      'issue_guid' => '',
      'message' => ''
    }
}
