{
  'info' => {
    'space' => 'gbmembers-template',
    'api_server' => 'https://gbmembers-template.kinops.io',
    'api_username' => 'unus.gaffoor@kineticdata.com',
    'api_password' => 'gbfms@2018',
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'ignore_status_values' => 'Dead Lead,Not Interested'
    }
}
