{
  'info' => {
    'server' => 'https://yourserver/kinetic',
    'username' => '',
    'password' => '',
    'space_slug' => '',
	'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'space_slug' => '',
    'team_name' => 'IT::Consulting',
    'members' => '["anne.ramey@kineticdata.com"]'
  }
}
