{
  'info' => {
    'api_server' => '',
    'api_username' => '',
    'api_password' => '',
    'space_slug' => '',
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
	'space_slug' => '',
    'current_username' => '',
    'display_name' => '',
    'email' => '',
    'preferred_locale' => '',
    'enabled' => '',
    'password' => '',
    'space_admin' => '',
    'new_username' => '',
    'append_or_replace' => 'Append',
    'attributes' =>  '[{"name": "Manager","values": []}]',
    'profile_attributes' => ''
  }
}