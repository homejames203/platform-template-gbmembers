{
  'info' => {
    'api_server' => 'https://my-server.com',
    'api_username' => '',
    'api_password' => '',
    'space_slug' => ''
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'space_slug' => '',
    'kapp_slug' => '',
    'form_slug' => ''
  }
}
