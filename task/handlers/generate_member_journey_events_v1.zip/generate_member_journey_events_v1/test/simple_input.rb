{
  'info' => {
    'space' => 'gbmembers-template',
    'api_server' => 'https://gbmembers-template.kinops.io',
    'api_username' => 'unus.gaffoor@kineticdata.com',
    'api_password' => 'gbfms@2018',
    'service_url' => 'https://gbbilling.com.au:8443/billingservice',
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'ignore_status_values' => '',
    'service_value' => 'overdues',
    'space' => 'gbmembers-template',
    'billing_company' => 'PaySmart',
    'json_args' => '{"space":"gbmembers-template", "billingService":"PaySmart"}'
    }
}
