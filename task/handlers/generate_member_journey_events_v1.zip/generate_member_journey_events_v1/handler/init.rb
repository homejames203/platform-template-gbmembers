# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

class GenerateMemberJourneyEventsV1
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    @api_server       =   @info_values['api_server']
    @api_username     =   URI.encode(@info_values['api_username'])
    @api_password     =   @info_values['api_password']

    # Load the debug logging and error handling info/parameter values into local variables
    @debug_logging_enabled = @info_values['enable_debug_logging'].downcase == 'yes' || @info_values['enable_debug_logging'] == 'true'
  end

  def execute
    # Initialize return data
    error_message = ""

    # To have the RestClient log to stdout (either the terminal if running the test harness or the
    # log file if running inside of task), set RestClient.log = "stdout" before making your Request
    # RestClient.log = "stdout"

    ################################################################################
    #               DOING A GET REQUEST TO RETRIEVE INFORMATION                    #
    ################################################################################
    space_route = "#{@api_server}/app/api/v1/space?include=details"
    space_resource = RestClient::Resource.new(space_route, { :user => @api_username, :password => @api_password })
    space_response = space_resource.get
    spaceResult = JSON.parse(space_response)
    tzName=spaceResult["space"]["defaultTimezone"]
    tz=TZInfo::Timezone.get(tzName)
    puts "tzName:#{tzName}"

    open_members_query = %|values[Status] IN ("Active","Pending Freeze","Pending Cancellation")|
    open_members_api_route = "#{@api_server}/app/api/v1/kapps/gbmembers/forms/member/submissions" +
              "?include=values,details&limit=1000&q=#{URI.escape(open_members_query)}"
    puts "open_members_api_route: #{open_members_api_route}"
    open_members_resource = RestClient::Resource.new(open_members_api_route, { :user => @api_username, :password => @api_password })
    open_members_response = open_members_resource.get
    membersResult = JSON.parse(open_members_response)
    openMembers = membersResult["submissions"].length
    puts "openMembers:#{openMembers}"

    inactive_members_query = %|values[Status] = "Inactive"|
    inactive_members_api_route = "#{@api_server}/app/api/v1/kapps/gbmembers/forms/member/submissions" +
              "?include=values,details&limit=1000&q=#{URI.escape(inactive_members_query)}"
    puts "inactive_members_api_route: #{inactive_members_api_route}"
    inactive_members_resource = RestClient::Resource.new(inactive_members_api_route, { :user => @api_username, :password => @api_password })
    inactive_members_response = inactive_members_resource.get
    inactiveMembersResult = JSON.parse(inactive_members_response)
    inactiveMembers = membersResult["submissions"].length
    puts "inactiveMembers:#{inactiveMembers}"

    member_journey_query = %|values[Status]="Active" AND values[Record Type]="Member"|
    member_journey_api_route = "#{@api_server}/app/api/v1/datastore/forms/journey-triggers/submissions" +
              "?include=values&index=values[Status],values[Record Type]&limit=1000&q=#{URI.escape(member_journey_query)}"
    puts "member_journey_api_route: #{member_journey_api_route}"
    member_journey_resource = RestClient::Resource.new(member_journey_api_route, { :user => @api_username, :password => @api_password })
    member_journey_response = member_journey_resource.get
    memberJourneyResult = JSON.parse(member_journey_response)
    memberJourneys = memberJourneyResult["submissions"].length
    puts "memberJourneys:#{memberJourneys}"

    headers = {
      :content_type => "application/json",
      :accept => "application/json"
    }
    puts "Calling the Billing Service URL:#{@parameters['service_url']}/#{@parameters['service_value']}" if @debug_logging_enabled
    billing_resource = RestClient::Resource.new("#{@parameters['service_url']}/#{@parameters['service_value']}",{:headers => headers})

    puts "Calling the Billing Service ARGS:#{@parameters['json_args']}" if @debug_logging_enabled
    begin
      billing_response = billing_resource.post("#{@parameters['json_args']}")
    rescue RestClient::Exception => e
        raise
    end
    #puts "billing_response:#{billing_response}"
    billingResponseResult = JSON.parse(billing_response)
    puts "overdues:#{billingResponseResult}"

    journeyTriggerMatches=[]
    events=[]
    for i in 0..memberJourneyResult["submissions"].length-1
      trigger = memberJourneyResult["submissions"][i]
      memberMatches = findMembersForTrigger(trigger, membersResult["submissions"], tz, billingResponseResult)
      puts "memberMatches #{memberMatches.length}"
      events=events.concat(createJourneyEvents(trigger, memberMatches))
    end

    for i in 0..memberJourneyResult["submissions"].length-1
      trigger = memberJourneyResult["submissions"][i]
      memberMatches = findMembersForTrigger(trigger, inactiveMembersResult["submissions"], tz, nil)
      puts "memberMatches #{memberMatches.length}"
      events=events.concat(createJourneyEvents(trigger, memberMatches))
    end

    # Return (and escape) the results that were defined in the node.xml
    results = <<-RESULTS
    <results>
      <result name="Result Event IDs">{
        "openmembers": #{openMembers},
        "memberJourneyEvents": #{events},
        }</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS

    return results
  end

  def findMembersForTrigger(trigger, members, tz, billingResponseResult)
      memberMatches=[]
      today=Date.today
      if trigger["values"]["Member Condition"]=="Converted"
        daysSince=trigger["values"]["Member Condition Duration"].to_i
        for i in 0..members.length-1
          createDate=Date.parse(members[i]['createdAt'])
          days=today.mjd - createDate.mjd
          if days==daysSince
            memberMatches[memberMatches.length]=members[i]
          end
        end
      end
      if trigger["values"]["Member Condition"]=="Cancelled"
        daysSince=trigger["values"]["Member Condition Duration"].to_i
        for i in 0..members.length-1
          updatedDate=Date.parse(members[i]['updatedAt'])
          history=(members[i]['Status History'].nil? || members[i]['Status History']=="" ? "[]" : members[i]['Status History'])
          history=JSON.parse(history)
          hist=nil
          if history.length>0
            hist=history[history.length-1]
          end
          if !hist.nil?
            updatedDate=Date.parse(hist["date"])
          end
          days=today.mjd - updatedDate.mjd
          if days==daysSince
            memberMatches[memberMatches.length]=members[i]
          end
        end
      end
      if trigger["values"]["Member Condition"]=="Last Attendance"
        daysSince=trigger["values"]["Member Condition Duration"].to_i
        for i in 0..members.length-1
          lastAttendance=members[i]["values"]["Last Attendance Date"]
          if !lastAttendance.nil? && lastAttendance!=""
              lastAttendance=Date.parse(lastAttendance)
              days=today.mjd - lastAttendance.mjd
              if days==daysSince
                if members[i]["values"]["DOB"].nil? || members[i]["values"]["DOB"]==""
                  dob=Date.parse(members[i]["values"]["DOB"])
                  if today.year-dob.year >= 16
                    memberMatches[memberMatches.length]=members[i]
                  end
                end
              end
          end
        end
      end
      if trigger["values"]["Member Condition"]=="Child Last Attendance"
        daysSince=trigger["values"]["Member Condition Duration"].to_i
        for i in 0..members.length-1
          lastAttendance=members[i]["values"]["Last Attendance Date"]
          if !lastAttendance.nil? && lastAttendance!=""
              lastAttendance=Date.parse(lastAttendance)
              days=today.mjd - lastAttendance.mjd
              if days==daysSince
                if !members[i]["values"]["DOB"].nil? && members[i]["values"]["DOB"]!=""
                  dob=Date.parse(members[i]["values"]["DOB"])
                  if today.year-dob.year < 16
                    memberMatches[memberMatches.length]=members[i]
                  end
                end
              end
          end
        end
      end
      if trigger["values"]["Member Condition"]=="Birthday"
        today_t = Time.now.utc
        daysSince=trigger["values"]["Member Condition Duration"].to_i
        for i in 0..members.length-1
            if !members[i]["values"]["DOB"].nil? && members[i]["values"]["DOB"]!=""
                dob=Date.parse(members[i]["values"]["DOB"])
                dob=tz.local_to_utc(Time.new(dob.year,dob.month,dob.day,0,0,0))
                #puts "DOB:#{members[i]["values"]["DOB"]} #{dob.month}-#{today_t.month} #{dob.mday}-#{today_t.mday}"
                if today_t.month==dob.month && today_t.mday==dob.mday
                  # => puts "#{members[i]["values"]["First Name"]} #{members[i]["values"]["Last Name"]}"
                  memberMatches[memberMatches.length]=members[i]
                end
            end
        end
      end
      if trigger["values"]["Member Condition"]=="New Belt"
        daysSince=trigger["values"]["Member Condition Duration"].to_i
        for i in 0..members.length-1
            if !members[i]["values"]["Last Promotion"].nil? && members[i]["values"]["Last Promotion"]!=""
                promotion=Date.parse(members[i]["values"]["Last Promotion"])
                if today.month==promotion.month && today.mday==promotion.mday
                  if trigger["values"]["Program"]==members[i]["values"]["Ranking Program"] && trigger["values"]["Belt"]==members[i]["values"]["Ranking Belt"]
                    memberMatches[memberMatches.length]=members[i]
                  end
                end
            end
        end
      end
      if trigger["values"]["Member Condition"]=="End of Term"
        daysSince=trigger["values"]["Member Condition Duration"].to_i
        for i in 0..members.length-1
            if !members[i]["values"]["Billing Cash Term End Date"].nil? && members[i]["values"]["Billing Cash Term End Date"]!=""
              endTerm=Date.parse(members[i]["values"]["Billing Cash Term End Date"])
              days=endTerm.mjd - today.mjd
              puts "days:#{days}"
              if days==daysSince
                memberMatches[memberMatches.length]=members[i]
              end
            end
        end
      end

      if trigger["values"]["Member Condition"]=="Payment Failed" && !billingResponseResult.nil? && !billingResponseResult["data"].nil?
        daysSince=trigger["values"]["Member Condition Duration"].to_i
        for i in 0..members.length-1
          if !members[i]["values"]["Billing Customer Id"].nil? && members[i]["values"]["Billing Customer Id"]!=""
              overdue=nil
              for x in 0..billingResponseResult["data"].length-1
                if billingResponseResult["data"][x]["customerReference"]==members[i]["values"]["Billing Customer Id"]
                  #puts "customerReference:#{billingResponseResult["data"][x]["customerReference"]}"
                    overdueDate=Date.parse(billingResponseResult["data"][x]["dateOverdue"])
                    days=today.mjd-overdueDate.mjd
                    puts "daysSince:#{daysSince} days:#{days}"
                    if days==daysSince
                      memberMatches[memberMatches.length]=members[i]
                    end
                end
              end
          end
        end
      end
      return memberMatches
  end

  def createJourneyEvents(trigger, memberMatches)
    events=[]
    journey_event_api_route = "#{@api_server}/app/api/v1/datastore/forms/journey-event/submissions"
    journey_event_resource = RestClient::Resource.new(journey_event_api_route, { :user => @api_username, :password => @api_password })

    for i in 0..memberMatches.length-1
      data = {}
      values={}
      values['Status']="New"
      values['Trigger ID']=trigger["id"]
      values['Record Type']=trigger["values"]["Record Type"]
      values['Record ID']=memberMatches[i]["id"]
      values['Record Name']=memberMatches[i]["values"]["First Name"]+" "+memberMatches[i]["values"]["Last Name"]
      values['Action']=trigger["values"]["Action"]
      values['Contact Type']=trigger["values"]["Contact Type"]
      values['Template Name']=trigger["values"]["Template Name"]

      data.tap do |json|
        json[:values] = values
      end
      response=nil
      begin
        response = journey_event_resource.post(data.to_json, { :accept => "json", :content_type => "json" })
      rescue RestClient::Exception => error
        puts "#{error.http_code}: #{JSON.parse(error.response)["error"]}"
      rescue Exception => error
        puts "#{error.inspect}"
      end
      if !response.nil?
        submission = JSON.parse(response)
        submission_id = submission['submission']['id']
        puts "SUBMISSION: #{submission_id}"
        events.push(submission_id)
      end
    end
    return events
  end
  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
end
