Kinetic Request CE Kapp Retrieve V1.1 (2018-05-25)
* API Server Info Value changed to allow ${space} in the url for subdomain support
(ie. https://${space}.localhost:8080/kinetic)

Kinetic Request CE Kapp Retrieve V1 (2016-04-28)
 * Initial version.  See README for details.
