{
  'info' => {
    'access_key' => '',
    'secret_key' => '',
    'region' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'region' => '',
    'bucket' => '',
    'file_content' => '',
    'file_name' => ''
  }
}