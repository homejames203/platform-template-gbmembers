{
  'info' => {
    'space' => 'gbsydney',
    'service_url' => 'https://gbbilling.com.au:8443/billingservice',
    'api_server' => 'https://gbsydney.kinops.io',
    'api_username' => 'unus.gaffoor@kineticdata.com',
    'api_password' => 'gbfms@2017',
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'billing_company' => 'PaySmart',
    'payments_args' => '{"billingService": "PaySmart","paymentType": "SUCCESSFUL","paymentMethod": "ALL","dateField": "PAYMENT","dateFrom": "2020-03-01","dateTo": "2020-03-31","internalPaymentType": "client_successful"}',
    'suspended_args' => '{"billingService": "PaySmart","fromDate": "2020-03-01","toDate": "2020-03-31"}'
    }
}
