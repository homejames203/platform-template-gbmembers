# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

class GenerateMonthlyBillingStatisticsV1
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    @api_server       =   @info_values['api_server']
    @api_username     =   URI.encode(@info_values['api_username'])
    @api_password     =   @info_values['api_password']

    # Load the debug logging and error handling info/parameter values into local variables
    @debug_logging_enabled = @info_values['enable_debug_logging'].downcase == 'yes' || @info_values['enable_debug_logging'] == 'true'
  end

  def execute
    # Initialize return data
    error_message = ""

    # To have the RestClient log to stdout (either the terminal if running the test harness or the
    # log file if running inside of task), set RestClient.log = "stdout" before making your Request
    # RestClient.log = "stdout"

    ################################################################################
    #               DOING A GET REQUEST TO RETRIEVE INFORMATION                    #
    ################################################################################

    headers = {
      :content_type => "application/json",
      :accept => "application/json"
    }
    totalMembers=0
    activeMembers=0
    inActiveMembers=0
    frozenMembers=0
    billingMembers=0
    nonPayingMembers=0
    income=0

    puts "Calling the Billing Payments Service URL:#{@parameters['service_url']}/payments" if @debug_logging_enabled
    resource = RestClient::Resource.new("#{@parameters['service_url']}/payments",{:headers => headers})

    puts "Calling the Billing Payments Service ARGS:#{@parameters['payments_args']}" if @debug_logging_enabled
    begin
      payments_args=JSON.parse(@parameters['payments_args'])
      payments_args["space"]="#{@parameters['space']}"
      puts "payments_args:#{JSON.dump(payments_args)}"
      response = resource.post(JSON.dump(payments_args))
    rescue RestClient::Exception => e
        raise
    end
    result=JSON.parse(response)
    puts "result:#{result}"
    data=result['data']
    for i in 0..data.length-1
      income += data[i]['scheduledAmount']
    end
    puts "income:#{income}"

    puts "Calling the Billing Suspended By Date Service URL:#{@parameters['service_url']}/getSuspendedCustomersCountByDate" if @debug_logging_enabled
    resource2 = RestClient::Resource.new("#{@parameters['service_url']}/getSuspendedCustomersCountByDate",{:headers => headers})

    puts "Calling the Billing Suspended Service ARGS:#{@parameters['suspended_args']}" if @debug_logging_enabled
    begin
      suspended_args=JSON.parse(@parameters['suspended_args'])
      suspended_args["space"]="#{@parameters['space']}"
      response2 = resource2.post(JSON.dump(suspended_args))
    rescue RestClient::Exception => e
        raise
    end
    result2=JSON.parse(response2)
    puts "response2:#{result2}"
    frozenMembers=result2["data"]["suspendedCount"]

    inactive_query = %|values[Status] IN ("Inactive","Frozen")|
    inactive_api_route = "#{@api_server}/app/api/v1/kapps/gbmembers/forms/member/submissions" +
                "?include=values&limit=1000&index=values[Status]&q=#{URI.escape(inactive_query)}"
    puts "inactive_api_route: #{inactive_api_route}"
    inactive_resource = RestClient::Resource.new(inactive_api_route, { :user => @api_username, :password => @api_password })
    inactive_response = inactive_resource.get
    inactiveResult = JSON.parse(inactive_response)
    inActiveMembers = inactiveResult["submissions"].length

    for i in 0..inactiveResult["submissions"].length-1
      member = inactiveResult["submissions"][i]
      if beingSuspended(member["values"]['Billing Customer Id'], result2["data"]["customerIds"])
        inActiveMembers = inActiveMembers - 1
      end
    end
    totalMembers=inActiveMembers+frozenMembers

    active_query = %|values[Status] IN ("Active","Pending Freeze","Pending Cancellation")|
    active_api_route = "#{@api_server}/app/api/v1/kapps/gbmembers/forms/member/submissions" +
                "?include=values&limit=1000&index=values[Status]&q=#{URI.escape(active_query)}"
    puts "active_api_route: #{active_api_route}"
    active_resource = RestClient::Resource.new(active_api_route, { :user => @api_username, :password => @api_password })
    active_response = active_resource.get
    activeResult = JSON.parse(active_response)

    for i in 0..activeResult["submissions"].length-1
      member = activeResult["submissions"][i]
      if member["values"]['Billing User'] == "YES" && beingSuspended(member["values"]['Billing Customer Id'], result2["data"]["customerIds"])
        # don't add
      else
        totalMembers = totalMembers + 1
        activeMembers = activeMembers + 1
      end
    end

    for i in 0..activeResult["submissions"].length-1
      member = activeResult["submissions"][i]
      if member["values"]['Billing User'] == "YES" && !beingSuspended(member["values"]['Billing Customer Id'], result2["data"]["customerIds"])
        billingMembers=billingMembers+1
      end
    end

    nonPayingMembers = activeMembers - billingMembers

    data=result['data']
    weeklyAmountTotal=0

    billingCustomers={}
    for i in 0..data.length-1
      billingCustomers[data[i]['customerBillingId']]=data[i]
    end
    billingCustomers.each do |key, value|
       customerId = key
  #     puts "customerId:#{customerId} name:#{data[i]['customerName']}"
        weeklyValue = getMemberWeeklyTotal(customerId, value['customerName'], value['scheduledAmount'], activeResult, inactiveResult)
  #     puts "weeklyTotal:#{weeklyAmountTotal} customerId:#{customerId} scheduledAmount:#{value['scheduledAmount']} weeklyValue:#{weeklyValue}"
       weeklyAmountTotal = weeklyAmountTotal + weeklyValue
    end
    puts "weeklyAmountTotal:#{weeklyAmountTotal}"

    weeklyAverage = weeklyAmountTotal / activeMembers

    # Return (and escape) the results that were defined in the node.xml
    results = <<-RESULTS
    <results>
      <result name="Result JSON">{
        "totalMembers": #{totalMembers},
        "activeMembers": #{activeMembers},
        "inActiveMembers": #{inActiveMembers},
        "frozenMembers": #{frozenMembers},
        "billingMembers": #{billingMembers},
        "nonPayingMembers": #{nonPayingMembers},
        "income": #{income},
        "aps": #{weeklyAverage}
        }</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS

    return results
  end

  def getMemberWeeklyTotal(customerId, name, scheduledAmount, activeResult, inactiveResult)
    member=nil
    for i in 0..activeResult["submissions"].length-1
      member = activeResult["submissions"][i]
      if member["values"]['Billing Customer Id'] == customerId
        period = member["values"]['Billing Payment Period']
        if period == "Weekly"
          return scheduledAmount
        elsif period == "Fortnightly"
          return scheduledAmount / 2
        elsif period == "Monthly"
          return (scheduledAmount * 12) / 52
        end
      end
    end

    for i in 0..inactiveResult["submissions"].length-1
      member = inactiveResult["submissions"][i]
      if member["values"]['Billing Customer Id'] == customerId
        period = member["values"]['Billing Payment Period']
        if period == "Weekly"
          return scheduledAmount
        elsif period == "Fortnightly"
          return scheduledAmount / 2
        elsif period == "Monthly"
          return (scheduledAmount * 12) / 52
        end
      end
    end
    #Assume Fortnightly
    #puts "customerId:#{customerId} Name:#{name}"

    return scheduledAmount / 2
  end

  def beingSuspended(customerId, customerIds)
  #  puts "customerId:#{customerId}"
  #  puts "customerIds:#{customerIds}"
  #  puts "result: #{(customerId.nil? || customerIds.index(customerId)==nil) ? false : true}"
    return (customerId.nil? || customerIds.index(customerId)==nil) ? false : true
  end
  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
end
