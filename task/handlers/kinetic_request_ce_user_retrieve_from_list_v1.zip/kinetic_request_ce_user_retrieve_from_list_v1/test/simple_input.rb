{
  'info' => {
    'api_server' => 'https://localhost:8080/kinetic',
    'api_username' => 'user@kineticdata.com',
    'api_password' => 'password',
    'space_slug' => 'acme'
  },
  'parameters' => {
    'space_slug' => 'matt-playground',
    'usernames' => 'matthew.howe@kineticdata.com,matthew.howe.2x@kineticdata.com'
  }
}
