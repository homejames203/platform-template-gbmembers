# Require the REXML ruby gem.  This is already included in the Kinetic Task
# engine, but will need to be available in the local JRuby gem repository if the
# handler is being run manually.
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))


require 'rexml/document'
# Require the necessary java libraries
# Require the necessary java libraries
library_path = File.join(File.expand_path(File.dirname(__FILE__)), "lib")
unless defined?(Javax::Activation::MimeType)
  $:.unshift(library_path) unless $:.include?(library_path)
  require 'activation.jar'
end
unless defined?(Org::Apache::Commons::Mail::Email)
  $:.unshift(library_path) unless $:.include?(library_path)
  require 'commons-email-1.2.jar'
end
unless defined?(Javax::Mail::Address)
  $:.unshift(library_path) unless $:.include?(library_path)
  require 'mailapi.jar'
end
unless defined?(Com::Sun::Mail::Smtp::SMTPMessage)
  $:.unshift(library_path) unless $:.include?(library_path)
  require 'smtp.jar'
end
require 'uri'

class SmtpEmailSendV1
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve the info values (see the get_info_value helper method below)
    @server = get_info_value(@input_document, 'server')
    @port = get_info_value(@input_document, 'port') || '25'
    @tls = get_info_value(@input_document, 'tls') || 'false'
    @tls = @tls.downcase
    @username = get_info_value(@input_document, 'username')
    @password = get_info_value(@input_document, 'password')

    @api_server = get_info_value(@input_document, 'api_server')
    @api_server_user = get_info_value(@input_document, 'api_server_user')
    @api_server_password = get_info_value(@input_document, 'api_server_password')
    @update_read_count_url = get_info_value(@input_document, 'update_read_count_url')

    # Retrieve the parameter values (see the get_parameter_value helper method below)
    @from = get_parameter_value(@input_document, 'from')
    @to = get_parameter_value(@input_document, 'to')
    @subject = get_parameter_value(@input_document, 'subject')
    @htmlbody = get_parameter_value(@input_document, 'htmlbody')
    @textbody = get_parameter_value(@input_document, 'textbody')

    @attachments = get_parameter_value(@input_document, 'attachments')
    @field_name = get_parameter_value(@input_document, 'fieldname')
    @memberId = get_parameter_value(@input_document, 'memberId')
    @campaignId = get_parameter_value(@input_document, 'campaignId')
    @space = get_parameter_value(@input_document, 'space')

    raise "Required parameter 'to' is blank." if @to.nil? || @to.length == 0
  end

  def execute()
    # Create the new email object
    email = org.apache.commons.mail.HtmlEmail.new()
    puts "smtp_email_send 0"

    # Set the required values
    email.setHostName(@server)
    email.setSmtpPort(@port.to_i)
    email.setTLS(@tls == 'true')
    puts "smtp_email_send 0a"
    email.setCharset("utf-8");
    # Unless there was not a user specified
    unless @username.nil? || @username.empty?
      # Set the email authentication
      email.setAuthentication(@username, @password)
    end
    puts "smtp_email_send 0bb #{@to}"

    # Set the messages values
    (@to || "").split(/\s*,\s*/).each { |address| email.addTo(address) }
    puts "smtp_email_send 0c"
    email.setFrom(@from)
    email.setSubject(@subject)
    puts "smtp_email_send 1"
    # Embed linked images into the html body if it is present
    unless @htmlbody.nil? || @htmlbody.empty?
      # Initialize a hash of image links to embeded values
      embedded_images = {}

      # Iterate over the body and embed necessary images
      @htmlbody.scan(/"cid:(.*)"/) do |match|
        # The match variable is an array of Regex groups (specified with
        # parentheses); in this case the first match is the url
        url = match.first
        # Unless we have already embedded this url
        unless embedded_images.has_key?(url)
          cid = email.embed(url, "Embedded image")
          embedded_images[url] = cid
        end
      end

      # Replace the image URLs with their embedded values
      embedded_images.each do |url, cid|
        @htmlbody.gsub!(url, cid)
      end
      puts "smtp_email_send 1 @campaignId#{@campaignId}"
      puts "smtp_email_send 1 @memberId#{@memberId}"

      if (!@campaignId.nil?)
        @htmlbody.gsub!('__campaign_id__', @campaignId)
        @htmlbody.gsub!('__member_id__', @memberId)
      end
      puts "smtp_email_send 1 @htmlbody.#{@htmlbody}"
      # Set the HTML message
      if (!@memberId.nil?)
        puts "smtp_email_send 1 imageUR:.#{'<img src="' + @update_read_count_url + '/' + @space + '/' + @campaignId + '/' +  @memberId + '/' + (Time.now.to_f * 1000).to_i.to_s + '.gif" alt="">'}"

        email.setHtmlMsg('<img src="' + @update_read_count_url + '/' + @space + '/' + @campaignId + '/' +  @memberId + '/' + (Time.now.to_f * 1000).to_i.to_s + '.gif" alt="">'+@htmlbody)
      else
        puts "Setting with no Member #{@htmlbody}"
        email.setHtmlMsg(@htmlbody)
      end
    end
    puts "smtp_email_send 2"

    # Set the plaintext message
    email.setTextMsg(@textbody);

	unless @attachments.nil? || @attachments.empty?
    puts "smtp_email_send 3"
	 	link = JSON.parse(@attachments)[0]
    puts "smtp_email_send 4"
		submissionId = link[/#{Regexp.escape("submissions/")}(.*?)#{Regexp.escape("/files")}/m, 1] # string_between_markers("submissions/", "/files")
    puts "smtp_email_send 5 #{submissionId}"
		files = getAttachmentUrl(submissionId, "Attachments")
    puts "smtp_email_send 6 #{files}"

		JSON.parse(files).each{|attachment|
      puts "smtp_email_send 7 #{attachment["url"]}"
		  email_attachment =  org.apache.commons.mail.EmailAttachment.new();
		  email_attachment.setDisposition("attachment");
		  email_attachment.setDescription(attachment["name"]);
		  email_attachment.setName(attachment["name"]);
		  email_attachment.setURL(java.net.URL.new(attachment["url"]));
		  email.attach(email_attachment);
	  }
    end

	# Send the email
    message_id = email.send();

    # Return the results
    <<-RESULTS
    <results>
      <result name='Message Id'>#{escape(message_id)}</result>
    </results>
    RESULTS
  # If we caught a EmailException error wrapper
  rescue org.apache.commons.mail.EmailException
    # Obtain the actual exception (which is in turn wrapped by NativeException)
    exception = $!.is_a?(NativeException) ? $!.cause : $!
    # Add the real exception string to the stacktrace
    if exception.respond_to?('cause') && exception.cause
      # Modify the message to include the cause
      raise Exception, "#{$!.message} [#{exception.cause.message}]", $!.backtrace
    # Otherwise raise the exception
    else
      raise $!
    end
  end

  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] }
  end

  # This is a sample helper method that illustrates one method for retrieving
  # values from the input document.  As long as your node.xml document follows
  # the standard format, the get_info_value and get_parameter_value methods are
  # all that are required to retrieve data from the input document.
  def get_info_value(document, name)
    # Retrieve the XML node representing the desird info value
    info_element = REXML::XPath.first(document, "/handler/infos/info[@name='#{name}']")
    # If the desired element is nil, return nil; otherwise return the text value of the element
    info_element.nil? ? nil : info_element.text
  end

  # This is a sample helper method that illustrates one method for retrieving
  # values from the input document.  As long as your node.xml document follows
  # the standard format, the get_info_value and get_parameter_value methods are
  # all that are required to retrieve data from the input document.
  def get_parameter_value(document, name)
    # Retrieve the XML node representing the desird info value
    parameter_element = REXML::XPath.first(document, "/handler/parameters/parameter[@name='#{name}']")
    # If the desired element is nil, return nil; otherwise return the text value of the element
    parameter_element.nil? ? nil : parameter_element.text
  end

 def getAttachmentUrl(submissionId, field_name)
   # Submission API Route including Values
      submission_api_route = @api_server + "/app/api/v1/submissions/" + URI.escape(submissionId) + "?include=values"
      puts "smtp_email_send 5a #{submission_api_route}"
	  # Retrieve the Submission Values
      submission_result = RestClient::Resource.new(
        submission_api_route,
        user: @api_server_user,
        password: @api_server_password
      ).get
      puts "smtp_email_send 5bb #{submission_result}"

      # If the submission exists
      unless submission_result.nil?
        submission = JSON.parse(submission_result)["submission"]
        puts "smtp_email_send 5c #{submission}"
        field_value = submission["values"][@field_name]
        puts "smtp_email_send 5d #{field_value}"
		#field_value = submission["values"]["Attachments"]
        # If the attachment field value exists
        unless field_value.nil?
          files = []
          # Attachment field values are stored as arrays, one map for each file attachment
          field_value.each_index do |index|
            file_info = field_value[index]
            # The attachment file name is stored in the 'name' property
            # API route to get the generated attachment download link from Kinetic Request CE.
            # "/{spaceSlug}/app/api/v1/submissions/{submissionId}/files/{fieldName}/{fileIndex}/{fileName}/url"
#            attachment_download_api_route = get_info_value(@input_document, 'api_server') +
#              file_info['link'] + "/url"
            attachment_download_api_route = @api_server +
              '/app/api/v1' +
              '/submissions/' + URI.escape(submissionId) +
              '/files/' + URI.escape("Attachments") +
              '/' + index.to_s +
              '/' + URI.escape(file_info['name']) +
              '/url'

            # Retrieve the URL to download the attachment from Kinetic Request CE.
            # This URL will only be valid for a short amount of time before it expires
            # (usually about 5 seconds).
            attachment_download_result = RestClient::Resource.new(
              attachment_download_api_route,
              user: @api_server_user,
			  password: @api_server_password
            ).get

            unless attachment_download_result.nil?
              url = JSON.parse(attachment_download_result)['url']
              file_info["url"] = url
            end
            file_info.delete("link")
            files << file_info
          end
        end
      end

	  files_json = files.nil? ? [] : JSON.dump(files)

  end

end
