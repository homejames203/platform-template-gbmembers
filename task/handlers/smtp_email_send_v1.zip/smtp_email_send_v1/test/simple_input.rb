{
  'info' => {
    'server' => 'pro.turbo-smtp.com',
    'port' => '25',
    'tls' => 'false',
    'username' => 'info@gbsydney.com.au',
    'password' => 'TdcjGVs5',
    'api_server' => 'https://gbmembers-template.kinops.io',
    'api_server_user' => 'unus.gaffoor@kineticdata.com',
    'api_server_password' => 'gbfms@2018',
    'update_read_count_url' => 'https://gbbilling.com.au:8443/billingservice/getCampaignImage',
  },
  'parameters' => {
    'from' => 'test.gboceania@gmail.com',
    'to' => 'unus.gaffoor@kineticdata.com',
    'subject' => 'Test Attachments',
    'htmlbody' => "<p>Hi member('Last Name'),</p><p><br></p><p>Can you please complete the following form prior to your Free Introduction Class:</p><p><a href=\"https://gbbilling.com.au:8443/billingservice/goToUrl/gbmembers-template/__campaign_id__/__member_id__/aHR0cDovLzE4LjIyMi4xODUuMjIxL2JpbGxpbmdzZXJ2aWNlL2dvVG9VcmwvX19jYW1wYWlnbl9pZF9fL19fbWVtYmVyX2lkX18vYUhSMGNITTZMeThrZTNOd1lXTmxmUzVyYVc1dmNITXVhVzh2SXk5cllYQndjeTl6WlhKMmFXTmxjeTltYjNKdGN5OXJhV1J6TFhKbFoybHpkSEpoZEdsdmJqOXdkV0pzYVdNbWFXUTliV1Z0WW1WeUtDZEpSQ2Nw\" rel=\"noopener noreferrer\" target=\"_blank\">https://${space}.kinops.io/#/kapps/services/forms/kids-registration?public&amp;id=member('ID')</a></p><p><br></p><p>Thanks</p><p><strong>${spaceAttributes('School Name')} Academy</strong></p><p>${spaceAttributes('School Address')}</p><p><br></p><p><a href=\"https://gbbilling.com.au:8443/billingservice/goToUrl/gbmembers-template/__campaign_id__/__member_id__/aHR0cDovLzE4LjIyMi4xODUuMjIxL2JpbGxpbmdzZXJ2aWNlL2dvVG9VcmwvX19jYW1wYWlnbl9pZF9fL19fbWVtYmVyX2lkX18vYUhSMGNEb3ZMekU0TGpJeU1pNHhPRFV1TWpJeEwySnBiR3hwYm1kelpYSjJhV05sTDJkdlZHOVZjbXd2WDE5allXMXdZV2xuYmw5cFpGOWZMMTlmYldWdFltVnlYMmxrWDE4dllVaFNNR05FYjNaTWVrVTBUR3BKZVUxcE5IaFBSRlYxVFdwSmVFd3lTbkJpUjNod1ltMWtlbHBZU2pKaFYwNXNUREprZGxaSE9WWmpiWGQyV0RFNWFsbFhNWGRaVjJ4dVltdzVjRnBHT1daTU1UbG1ZbGRXZEZsdFZubFlNbXhyV0RFNGRsbFZhRk5OUjA1RllqTmFUV1ZyVlRCVVIzQktaVlV4Y0U1SWFGQlNSbFl4VkZkd1NtVkZkM2xUYmtKcFVqTm9kMWx0TVd0bGJIQlpVMnBLYUZZd05YTlVSRXByWkd4YVNFOVdXbXBpV0dReVYwUkZOV0ZzYkZoTldHUmFWako0ZFZsdGR6VmpSbkJIVDFkYVRVMVViRzFaYkdSWFpFWnNkRlp1YkZsTmJYaHlWMFJGTkdSc2JGWmhSazVPVWpBMVJsbHFUbUZVVjFaeVZsUkNWVkl6UWt0YVZsVjRZMFUxU1dGR1FsTlNiRmw0Vmtaa2QxTnRWa1prTTJ4VVltdEtjRlZxVG05a01XeDBUVmQwYkdKSVFscFZNbkJMWVVaWmQwNVlUbFZTUlhCeVdrZDRZVk5GT1ZkWGJYQnBWMGRSZVZZd1VrWk9WMFp6WWtab1RsZEhVbUZXYWtvMFpGWnNkR1I2Vm1wU2JrSklWREZrWVZSVk1WVmlSekZhWWtkU1dGcEZXbk5rUmxwMVlrWnNUbUpZYUhsV01GSkdUa2RTYzJORldtRlNiVkp4VkZWU2MyUXhXbGhqUjNSb1lYcENNMVV5TURWWFJscEdZMFpvVmxaNlJsUlZNVnBYWkZkS1NHRkdaRTVTZW1zd1ZqSjBWMkV4V1hsV2JrcHJVbFpLYUZWdGVFdFpWbEpZVFZjNVRtSkhlSGhWTW5CUFdWVXhWMk5GYkZkaVZGWlFWMVphYTFKc1RuVlhiSEJvWVRKME5GZFhkRmRrTURWWVUydFdhR1ZxUVRrPQ==\" rel=\"noopener noreferrer\" target=\"_blank\">${spaceAttributes('School Telephone')}</a></p><p><a href=\"https://gbbilling.com.au:8443/billingservice/goToUrl/gbmembers-template/__campaign_id__/__member_id__/aHR0cDovLzE4LjIyMi4xODUuMjIxL2JpbGxpbmdzZXJ2aWNlL2dvVG9VcmwvX19jYW1wYWlnbl9pZF9fL19fbWVtYmVyX2lkX18vYUhSMGNEb3ZMekU0TGpJeU1pNHhPRFV1TWpJeEwySnBiR3hwYm1kelpYSjJhV05sTDJkdlZHOVZjbXd2WDE5allXMXdZV2xuYmw5cFpGOWZMMTlmYldWdFltVnlYMmxrWDE4dllVaFNNR05FYjNaTWVrVTBUR3BKZVUxcE5IaFBSRlYxVFdwSmVFd3lTbkJpUjNod1ltMWtlbHBZU2pKaFYwNXNUREprZGxaSE9WWmpiWGQyV0RFNWFsbFhNWGRaVjJ4dVltdzVjRnBHT1daTU1UbG1ZbGRXZEZsdFZubFlNbXhyV0RFNGRsbFZhRk5OUjA1RllqTmFUV1ZyVlRCVVIzQktaVlV4Y0U1SWFGQlNSbFl4VkZkd1NtVkZkM2xUYmtKcFVqTm9kMWx0TVd0bGJIQlpVMnBLYUZZd05YTlVSRXByWkd4YVNFOVdXbXBpV0dReVYwUkZOV0ZzYkZoTldHUmFWako0ZFZsdGR6VmpSbkJIVDFkYVRVMVViRzFaYkdSWFpFWnNkRlp1YkZsTmJYaHlWMFJGTkdSc2JGWmhSazVPVWpBMVJsbHFUbUZVVjFaeVZsUkNWVkl6UWt0YVZsVjRZMFUxU1dGR1FsTlNiRmw0Vmtaa2QxTnRWa1prTTJ4VVltdEtjRlZxVG05a01XeDBUVmQwYkdKSVFscFZNbkJMWVVaWmQwNVlUbFZTUlhCeVdrZDRZVk5GT1ZkWGJYQnBWMGRSZVZZd1VrWk9WMFp6WWtab1RsZEhVbUZXYWtvMFpGWnNkR1I2Vm1wU2JrSklWREZrWVZSVk1WVmlSekZhWWtkU1dGcEZXbk5rUmxwMVlrWnNUbUpZYUhsV01GSkdUa2RTYzJKSVRtRlNWMUp4VldwQ2QxTnNXbGhPVjBaV1VqQmFXRlV4VWs5WGJWWnlUbFZTV2xaV2NIbGFWbHBoWTJ4T2RHUkdVbE5oTWpoNFZqRmFZV0V4VFhkTlZtaFdZVEpvV0ZsdE5VTlVWbFpWVTJ4T1YxWnRVbFpWTWpBMVlUSktWbUpFVm1GU1JYQnlWbFJHWVU1c1NuUlBWbkJYWWxaR05sZFhNVEJOUm1SV1RWVldUbEpFUVRrPQ==\" rel=\"noopener noreferrer\" target=\"_blank\">${spaceAttributes('School Email')}</a></p><div id='__gbmembers-lead-363fda32-5536-11e9-9fd7-0511bcd7abbe' />",
    'textbody' => "Thanks from Kinetic Data.",
    'attachments' => '',
    'fieldname' => "Attachments",
    'memberId' => "b7898ed5-55ce-11e9-af5a-6326a7a77f9e",
    'campaignId' => "aae40fe2-35bf-11ea-a2f2-bb8eedb84cd5",
    'space' => "gbmembers-template"
  }
}
