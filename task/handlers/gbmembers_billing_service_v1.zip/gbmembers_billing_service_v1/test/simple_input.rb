{
  'info' => {
    'server_location' => '',
    'username' => '',
    'password' => '',
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'menu_dropdown' => '',
    'manual_input' => '',
    'optional_param' => ''
  }
}