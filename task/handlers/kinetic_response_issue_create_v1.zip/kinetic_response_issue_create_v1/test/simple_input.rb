{
  'info' => {
    'api_server' => '',
    'api_username' => '',
    'api_password' => '',
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'name' => '',
    'description' => '',
    'owner_email' => '',
    'tag_list' => '',
    'api_server' => ''
  }
}
