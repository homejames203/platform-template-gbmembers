# -*- coding: utf-8 -*-
#
# Require the Kinetic::Commons module
require File.expand_path(File.join(File.dirname(__FILE__), "commons"))

# Required to function as a Task Handler
class KineticCommonsModuleV1
  def initialize(input); end
  def execute; end
end
