# -*- coding: utf-8 -*-
#
handler_path = File.expand_path(File.dirname(__FILE__))
unless defined?(Kramdown)
  # Load the Kramdown library unless it has already been loaded.
  # This library provides Markdown syntax support.
  library_path = File.join(handler_path, "vendor", "kramdown-1.13.2", "lib")
  $:.unshift library_path
  # Require the library
  require "kramdown"
end
