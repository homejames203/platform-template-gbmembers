# -*- coding: utf-8 -*-
#
require 'cgi'
# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

# Kinetic::Commons module
module Kinetic
  module Commons

    # Escapes XML characters (&, ", <, and >) so that they themselves can be rendered in XML.
    #
    # Usage:  ::Kinetic::Commons.escape("<div>Hello World!</div>")
    #
    def self.escape(string)
      CGI.escapeHTML(string.to_s)
    end

    # Generate HTML from Markdown using Github Flavored Markdown parser.
    #
    # Usage:  ::Kinetic::Commons.gfm_to_html("string")
    #
    # This is the same as calling
    #         ::Kinetic::Commons.md_to_html("string", :input => "GFM")
    #
    def self.gfm_to_html(string, options={})
      options[:input => "GFM"] unless options[:input]
      self.md_to_html(string, options)
    end

    # Generate HTML from Markdown.
    #
    # Usage:  ::Kinetic::Commons.md_to_html("string")
    #
    def self.md_to_html(string, options={})
      options[:auto_ids => false] unless options[:auto_ids]
      if string
        # ensure string is UTF-8 encoded
        string = string.encode("UTF-8")
        if options[:input]
          html = Kramdown::Document.new(string, options).to_html
        else
          html = Kramdown::Document.new(string, options.merge(:input => "kramdown")).to_html
        end
      end
    end

  end
end
