{
  'info' => {
    'api_username' => '',
    'api_password' => '',
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'api_server' => '',
    'error_handling' => 'Error Message',
    'issue_guid' => '',
    'issue_name' => '',
    'issue_description' => '',
    'owner_email' => '',
    'tag_list' => ''
  }
}
